import time

def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(3)

def intro():
    print("You have just arrived at your new job!")
    print("You are on the elevator.")
    print("Please enter the number for the floor you would like to visit:")

def make_selection():
    response = valid_input("Please enter the number for the floor you would like to visit:"
                            "1. Lobby"
                            "2. Human resources"
                            "3. Engineering department")

    if "1. Lobby" in reponse:
        print_pause("You push the button for the first floor."
                    "After a few moments, you find yourself in the lobby.""
                    "Where would you like to go next?"
                    "Please enter the number for the floor you would like to visit:")
